#!/bin/bash
tar -cvzf file.tar.gz *
scp "/home/abhi/git/DistanceVector/DV/src/file.tar.gz" asampath@silo.soic.indiana.edu:/u/asampath/final_test/DV1/
scp "/home/abhi/git/DistanceVector/DV/src/file.tar.gz" asampath@silo.soic.indiana.edu:/u/asampath/final_test/DV2/
scp "/home/abhi/git/DistanceVector/DV/src/file.tar.gz" asampath@silo.soic.indiana.edu:/u/asampath/final_test/DV3/
scp "/home/abhi/git/DistanceVector/DV/src/file.tar.gz" asampath@silo.soic.indiana.edu:/u/asampath/final_test/DV4/
scp "/home/abhi/git/DistanceVector/DV/src/file.tar.gz" asampath@silo.soic.indiana.edu:/u/asampath/final_test/DV5/




