#!/bin/bash
tar -cvzf file.tar.gz *
scp "/Users/tanmay/Desktop/FALL 15/ComputerNetworks/VimSource/Final Project/DistanceVectorAbhi/DV/src/file.tar.gz" tbindi@silo.soic.indiana.edu:/u/tbindi/final_test/DV1/
scp "/Users/tanmay/Desktop/FALL 15/ComputerNetworks/VimSource/Final Project/DistanceVectorAbhi/DV/src/file.tar.gz" tbindi@silo.soic.indiana.edu:/u/tbindi/final_test/DV2/
scp "/Users/tanmay/Desktop/FALL 15/ComputerNetworks/VimSource/Final Project/DistanceVectorAbhi/DV/src/file.tar.gz" tbindi@silo.soic.indiana.edu:/u/tbindi/final_test/DV3/
scp "/Users/tanmay/Desktop/FALL 15/ComputerNetworks/VimSource/Final Project/DistanceVectorAbhi/DV/src/file.tar.gz" tbindi@silo.soic.indiana.edu:/u/tbindi/final_test/DV4/
scp "/Users/tanmay/Desktop/FALL 15/ComputerNetworks/VimSource/Final Project/DistanceVectorAbhi/DV/src/file.tar.gz" tbindi@silo.soic.indiana.edu:/u/tbindi/final_test/DV5/